<template>
  <div class="container mx-auto p-4 max-w-7xl">
    <div class="text-center mb-8">
      <h1 class="text-4xl font-bold text-gray-800 mb-2">FileLoader</h1>
      <p class="text-gray-600 text-lg">Загружайте, храните и обменивайтесь файлами любых форматов быстро и безопасно</p>
    </div>

    <!-- Таблица поддерживаемых форматов -->
    <div class="mb-8 bg-white rounded-xl shadow-sm p-6 border border-gray-200">
      <h2 class="text-xl font-semibold text-gray-800 mb-4">Поддерживаемые форматы</h2>
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Тип
                файла</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Форматы</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Макс. размер</th>
              <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Иконка</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr class="hover:bg-gray-50 transition-colors">
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Изображения</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">JPG, PNG, GIF, WEBP, SVG</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">50 MB</td>
              <td class="px-6 py-4 whitespace-nowrap">
                <component :is="ImageIcon" class="w-5 h-5 text-blue-500" />
              </td>
            </tr>
            <tr class="hover:bg-gray-50 transition-colors">
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Документы</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">PDF, DOCX, XLSX, PPTX, TXT</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">30 MB</td>
              <td class="px-6 py-4 whitespace-nowrap">
                <component :is="FileIcon" class="w-5 h-5 text-blue-500" />
              </td>
            </tr>
            <tr class="hover:bg-gray-50 transition-colors">
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Видео</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">MP4, MOV, AVI, MKV</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">100 MB</td>
              <td class="px-6 py-4 whitespace-nowrap">
                <component :is="VideoIcon" class="w-5 h-5 text-blue-500" />
              </td>
            </tr>
            <tr class="hover:bg-gray-50 transition-colors">
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Аудио</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">MP3, WAV, OGG</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">20 MB</td>
              <td class="px-6 py-4 whitespace-nowrap">
                <component :is="AudioIcon" class="w-5 h-5 text-blue-500" />
              </td>
            </tr>
            <tr class="hover:bg-gray-50 transition-colors">
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Архивы</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">ZIP, RAR, 7Z, TAR.GZ</td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">200 MB</td>
              <td class="px-6 py-4 whitespace-nowrap">
                <component :is="ArchiveIcon" class="w-5 h-5 text-blue-500" />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Форма загрузки файлов -->
    <form @submit.prevent="uploadFile" class="mb-8">
      <div class="flex flex-col items-center justify-center w-full">
        <!-- Дропзона -->
        <label for="dropzone-file"
          class="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-xl cursor-pointer transition-all"
          :class="[
            dragOver
              ? 'border-blue-500 bg-blue-50/50'
              : 'border-gray-300 hover:border-gray-400 bg-gray-50',
            file ? 'h-32' : 'h-64'
          ]" @dragover.prevent="handleDragOver" @dragleave="handleDragLeave" @drop.prevent="handleDrop">
          <div v-if="previewUrl" class="w-full h-full flex items-center justify-center p-4">
            <img :src="previewUrl" alt="File preview" class="max-w-full max-h-full object-contain rounded-lg" />
          </div>

          <div v-else class="flex flex-col items-center justify-center p-6 text-center">
            <svg class="w-10 h-10 mb-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <p class="mb-1 text-sm text-gray-500">
              <span class="font-medium text-gray-600">Нажмите для загрузки</span> или перетащите файл
            </p>
            <p class="text-xs text-gray-400">Поддерживаются файлы до 200MB</p>
          </div>
          <input id="dropzone-file" type="file" class="hidden" @change="onFileChange" />
        </label>

        <!-- Блок с выбранным файлом и формой ввода -->
        <div v-if="file" class="w-full mt-4 p-4 bg-white border border-gray-200 rounded-lg shadow-xs transition-all">
          <div class="space-y-4">
            <div class="flex items-center justify-between gap-3">
              <div class="flex items-center gap-3 min-w-0">
                <div class="flex-shrink-0 p-2 bg-blue-50 rounded-lg text-blue-500">
                  <component :is="fileIcon(file)" class="w-5 h-5" />
                </div>
                <div class="min-w-0">
                  <p class="text-sm font-medium text-gray-800 truncate">{{ file.name }}</p>
                  <p class="text-xs text-gray-500">{{ formatFileSize(file.size) }}</p>
                </div>
              </div>
            </div>

            <!-- Поля для ввода названия и описания -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Название файла</label>
              <input v-model="fileMeta.customName" type="text"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Введите название файла" maxlength="100">
              <p class="text-xs text-gray-500 mt-1">{{ fileMeta.customName.length }}/100</p>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Описание</label>
              <textarea v-model="fileMeta.description" rows="3"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Введите описание файла" maxlength="500" @input="limitDescription"></textarea>
              <p class="text-xs text-gray-500 mt-1">{{ fileMeta.description.length }}/500</p>
            </div>
          </div>

          <div class="mt-4 flex justify-end">
            <button type="submit"
              class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center justify-center"
              :class="{ 'opacity-50 cursor-not-allowed': uploading }" :disabled="uploading">
              <template v-if="!uploading">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                Загрузить
              </template>
              <template v-else>
                <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none"
                  viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                  </path>
                </svg>
                Загрузка...
              </template>
            </button>
          </div>
        </div>

        <!-- Прогресс-бар -->
        <div v-if="progress > 0" class="w-full mt-4">
          <div class="flex items-center justify-between mb-1">
            <span class="text-xs font-medium text-blue-600">{{ progress }}%</span>
            <span class="text-xs text-gray-500">{{ formatFileSize((file.size * progress) / 100) }} из {{
              formatFileSize(file.size) }}</span>
          </div>
          <div class="w-full bg-gray-200 rounded-full h-2">
            <div class="bg-blue-600 h-2 rounded-full progress-bar-transition" :style="{ width: `${progress}%` }"></div>
          </div>
        </div>
      </div>
    </form>
    <!-- Руководство пользователя -->
    <div class="mb-8 bg-white rounded-xl shadow-sm p-6 border border-gray-200">
      <h2 class="text-xl font-semibold text-gray-800 mb-4">📚 Руководство пользователя</h2>

      <div class="space-y-3">
        <!-- Аккордеон 1 -->
        <div class="border border-gray-200 rounded-lg overflow-hidden">
          <button @click="toggleAccordion('upload')"
            class="w-full flex justify-between items-center p-4 text-left hover:bg-gray-50 transition-colors">
            <span class="font-medium text-gray-800">Как загрузить файл?</span>
            <svg class="w-5 h-5 text-gray-500 transform transition-transform"
              :class="{ 'rotate-180': activeAccordion === 'upload' }" fill="none" viewBox="0 0 24 24"
              stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <div v-show="activeAccordion === 'upload'" class="px-4 pb-4 text-sm text-gray-600">
            <ol class="list-decimal pl-5 space-y-2">
              <li>Нажмите на область загрузки или перетащите файл в выделенную зону</li>
              <li>Дождитесь появления информации о файле</li>
              <li>Укажите название и описание файла (необязательно)</li>
              <li>Нажмите кнопку "Загрузить"</li>
              <li>Дождитесь завершения загрузки</li>
            </ol>
          </div>
        </div>

        <!-- Аккордеон 2 -->
        <div class="border border-gray-200 rounded-lg overflow-hidden">
          <button @click="toggleAccordion('manage')"
            class="w-full flex justify-between items-center p-4 text-left hover:bg-gray-50 transition-colors">
            <span class="font-medium text-gray-800">Управление файлами</span>
            <svg class="w-5 h-5 text-gray-500 transform transition-transform"
              :class="{ 'rotate-180': activeAccordion === 'manage' }" fill="none" viewBox="0 0 24 24"
              stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <div v-show="activeAccordion === 'manage'" class="px-4 pb-4 text-sm text-gray-600">
            <ul class="list-disc pl-5 space-y-2">
              <li><span class="font-medium">Редактирование:</span> Нажмите на иконку карандаша чтобы изменить название и
                описание</li>
              <li><span class="font-medium">Копирование ссылки:</span> Нажмите на иконку копирования чтобы получить
                ссылку
                на файл</li>
              <li><span class="font-medium">Скачивание:</span> Нажмите кнопку "Скачать" для загрузки файла</li>
              <li><span class="font-medium">Удаление:</span> Нажмите кнопку "Удалить" чтобы убрать файл из списка</li>
            </ul>
          </div>
        </div>

        <!-- Аккордеон 3 -->
        <div class="border border-gray-200 rounded-lg overflow-hidden">
          <button @click="toggleAccordion('formats')"
            class="w-full flex justify-between items-center p-4 text-left hover:bg-gray-50 transition-colors">
            <span class="font-medium text-gray-800">Поддерживаемые форматы</span>
            <svg class="w-5 h-5 text-gray-500 transform transition-transform"
              :class="{ 'rotate-180': activeAccordion === 'formats' }" fill="none" viewBox="0 0 24 24"
              stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <div v-show="activeAccordion === 'formats'" class="px-4 pb-4 text-sm text-gray-600">
            <div class="grid grid-cols-2 gap-2">
              <div>
                <p class="font-medium">Изображения:</p>
                <p class="text-gray-500">JPG, PNG, GIF, WEBP, SVG</p>
              </div>
              <div>
                <p class="font-medium">Документы:</p>
                <p class="text-gray-500">PDF, DOCX, XLSX, PPTX, TXT</p>
              </div>
              <div>
                <p class="font-medium">Видео:</p>
                <p class="text-gray-500">MP4, MOV, AVI, MKV</p>
              </div>
              <div>
                <p class="font-medium">Аудио:</p>
                <p class="text-gray-500">MP3, WAV, OGG</p>
              </div>
              <div>
                <p class="font-medium">Архивы:</p>
                <p class="text-gray-500">ZIP, RAR, 7Z, TAR.GZ</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Аккордеон 4 -->
        <div class="border border-gray-200 rounded-lg overflow-hidden">
          <button @click="toggleAccordion('limits')"
            class="w-full flex justify-between items-center p-4 text-left hover:bg-gray-50 transition-colors">
            <span class="font-medium text-gray-800">Ограничения</span>
            <svg class="w-5 h-5 text-gray-500 transform transition-transform"
              :class="{ 'rotate-180': activeAccordion === 'limits' }" fill="none" viewBox="0 0 24 24"
              stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <div v-show="activeAccordion === 'limits'" class="px-4 pb-4 text-sm text-gray-600">
            <ul class="list-disc pl-5 space-y-2">
              <li>Максимальный размер файла: <span class="font-medium">200 MB</span></li>
              <li>Максимальная длина названия: <span class="font-medium">100 символов</span></li>
              <li>Максимальная длина описания: <span class="font-medium">500 символов</span></li>
              <li>Файлы хранятся только в вашем браузере (localStorage)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Список загруженных файлов -->
    <div v-if="uploadedFiles.length > 0">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div v-for="(file, index) in uploadedFiles" :key="index"
          class="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden flex flex-col"
          style="min-height: 420px">
          <!-- Превью для изображений -->
          <div v-if="isImage(file)" class="h-56 bg-gray-100 overflow-hidden flex-shrink-0">
            <img :src="file.url" :alt="file.name"
              class="w-full h-full object-cover transition-transform hover:scale-105" @error="handleImageError" />
          </div>

          <!-- Заглушка для других файлов -->
          <div v-else class="h-56 bg-gray-50 flex items-center justify-center flex-shrink-0">
            <div class="p-4 bg-blue-50 rounded-full text-blue-500">
              <component :is="fileIcon(file)" class="w-12 h-12" />
            </div>
          </div>

          <!-- Информация о файле -->
          <div class="p-4 flex flex-col flex-grow">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <p class="text-sm font-medium text-gray-900 truncate">{{ file.customName || file.name }}</p>
                <div v-if="file.description"
                  class="mt-2 text-xs text-gray-600 h-24 overflow-y-auto description-scroll pr-2">
                  {{ file.description }}
                </div>
                <p class="text-sm text-gray-500 mt-2">{{ formatFileSize(file.size) }}</p>
                <p class="text-xs text-gray-400 mt-1">{{ formatDate(file.uploadedAt) }}</p>
              </div>
              <div class="flex space-x-2">
                <button @click="editFile(index)" class="text-gray-400 hover:text-gray-600" title="Редактировать">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                </button>
                <button @click="copyLink(file.url)" class="text-gray-400 hover:text-gray-600" title="Копировать ссылку">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                  </svg>
                </button>
              </div>
            </div>

            <div class="mt-auto pt-3 flex space-x-3">
              <a :href="file.url" target="_blank"
                class="flex-1 px-3 py-2 bg-blue-50 text-blue-600 hover:bg-blue-100 text-sm font-medium rounded text-center">
                Скачать
              </a>
              <button @click="deleteFile(index)"
                class="flex-1 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 text-sm font-medium rounded">
                Удалить
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Модальное окно редактирования -->
    <div v-if="editingFile !== null"
      class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div class="bg-white rounded-xl shadow-lg w-full max-w-md">
        <div class="p-6">
          <h3 class="text-lg font-medium text-gray-900 mb-4">Редактирование файла</h3>

          <div class="space-y-4">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Название</label>
              <input v-model="editingData.customName" type="text"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Введите название файла" maxlength="100">
              <p class="text-xs text-gray-500 mt-1">{{ editingData.customName.length }}/100</p>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Описание</label>
              <textarea v-model="editingData.description" rows="3"
                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Введите описание файла" maxlength="500" @input="limitDescription"></textarea>
              <p class="text-xs text-gray-500 mt-1">{{ editingData.description.length }}/500</p>
            </div>
          </div>

          <div class="mt-6 flex justify-end space-x-3">
            <button @click="editingFile = null"
              class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md">
              Отмена
            </button>
            <button @click="saveFileEdit"
              class="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md">
              Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// Иконки файлов
const FileIcon = {
  template: `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
    </svg>
  `
}

const ImageIcon = {
  template: `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
    </svg>
  `
}

const VideoIcon = {
  template: `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
    </svg>
  `
}

const AudioIcon = {
  template: `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/>
    </svg>
  `
}

const ArchiveIcon = {
  template: `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
    </svg>
  `
}

export default {
  components: { FileIcon, ImageIcon, VideoIcon, AudioIcon, ArchiveIcon },

  data() {
    return {
      file: null,
      previewUrl: null,
      progress: 0,
      uploading: false,
      uploadedFiles: [],
      dragOver: false,
      editingFile: null,
      activeAccordion: null,
      editingData: {
        customName: '',
        description: ''
      },
      fileMeta: {
        customName: '',
        description: ''

      }

    }
  },

  created() {
    // Загрузка сохраненных файлов из localStorage
    const savedFiles = JSON.parse(localStorage.getItem('uploadedFiles')) || []
    this.uploadedFiles = savedFiles.map(file => ({
      ...file,
      uploadedAt: new Date(file.uploadedAt)
    }))
  },

  methods: {
    toggleAccordion(section) {
      this.activeAccordion = this.activeAccordion === section ? null : section
    },

    onFileChange(event) {
      const file = event.target.files[0]
      if (file) {
        this.file = file
        this.generatePreview(file)
      }
    },

    handleDragOver() {
      this.dragOver = true
    },

    handleDragLeave() {
      this.dragOver = false
    },

    handleDrop(event) {
      this.dragOver = false
      const files = event.dataTransfer.files
      if (files.length > 0) {
        this.file = files[0]
        this.generatePreview(files[0])
      }
    },

    generatePreview(file) {
      if (this.previewUrl) {
        URL.revokeObjectURL(this.previewUrl)
      }

      if (file && this.isImage(file)) {
        this.previewUrl = URL.createObjectURL(file)
      } else {
        this.previewUrl = null
      }
    },

    fileIcon(file) {
      if (!file) return FileIcon

      if (file.type) {
        if (file.type.startsWith('image/')) return ImageIcon
        if (file.type.startsWith('video/')) return VideoIcon
        if (file.type.startsWith('audio/')) return AudioIcon
        if (file.type.includes('zip') || file.type.includes('compressed')) return ArchiveIcon
      }

      if (file.name) {
        const extension = file.name.split('.').pop().toLowerCase()
        const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']
        const videoExtensions = ['mp4', 'mov', 'avi', 'mkv']
        const audioExtensions = ['mp3', 'wav', 'ogg']
        const archiveExtensions = ['zip', 'rar', '7z', 'tar', 'gz']

        if (imageExtensions.includes(extension)) return ImageIcon
        if (videoExtensions.includes(extension)) return VideoIcon
        if (audioExtensions.includes(extension)) return AudioIcon
        if (archiveExtensions.includes(extension)) return ArchiveIcon
      }

      return FileIcon
    },

    isImage(file) {
      if (!file) return false

      if (file.type) {
        return file.type.startsWith('image/')
      }

      if (file.name) {
        const extension = file.name.split('.').pop().toLowerCase()
        const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']
        return imageExtensions.includes(extension)
      }

      return false
    },

    formatFileSize(bytes) {
      if (bytes === 0) return '0 Bytes'
      const k = 1024
      const sizes = ['Bytes', 'KB', 'MB', 'GB']
      const i = Math.floor(Math.log(bytes) / Math.log(k))
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
    },

    formatDate(date) {
      if (!date) return ''
      const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }
      return new Date(date).toLocaleDateString('ru-RU', options)
    },

    handleImageError(e) {
      e.target.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Ik0zIDlhMiAyIDAgMCAxIDItMmgxNGEyIDIgMCAwIDEgMiAydjZhMiAyIDAgMCAxLTIgMkg1YTIgMiAwIDAgMS0yLTJWIjl6Ij48L3BhdGg+PHBhdGggZD0iTTE1IDEzLjVhMS41IDEuNSAwIDEtMyAwIDEuNSAxLjUgMCAwMTMgMHoiPjwvcGF0aD48cGF0aCBkPSJNMTIgMTJhMyAzIDAgMTAwLTYgMyAzIDAgMDAwIDZ6Ij48L3BhdGg+PC9zdmc+'
    },

    async uploadFile() {
      if (!this.file || this.uploading) return

      this.uploading = true
      this.progress = 0

      const simulateProgress = () => {
        return new Promise((resolve) => {
          const interval = setInterval(() => {
            if (this.progress < 90) {
              this.progress += 10
            } else {
              clearInterval(interval)
              resolve()
            }
          }, 300)
        })
      }

      try {
        await simulateProgress()

        const formData = new FormData()
        formData.append('file', this.file)

        const xhr = new XMLHttpRequest()

        xhr.upload.addEventListener('progress', (event) => {
          if (event.lengthComputable) {
            this.progress = 90 + Math.round((event.loaded / event.total) * 10)
          }
        })

        const response = await new Promise((resolve, reject) => {
          xhr.onreadystatechange = () => {
            if (xhr.readyState === 4) {
              if (xhr.status === 200) {
                resolve(JSON.parse(xhr.responseText))
              } else {
                reject(new Error('Ошибка загрузки'))
              }
            }
          }

          xhr.open('POST', 'http://localhost:3000/upload', true)
          xhr.send(formData)
        })

        this.progress = 100

        this.uploadedFiles.unshift({
          name: this.file.name,
          size: this.file.size,
          url: response.fileUrl,
          type: this.file.type,
          customName: this.fileMeta.customName,
          description: this.fileMeta.description,
          uploadedAt: new Date()
        })

        localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles))

        await new Promise(resolve => setTimeout(resolve, 500))
        this.file = null
        this.previewUrl = null
        this.fileMeta = { customName: '', description: '' }
        this.progress = 0
      } catch (error) {
        console.error('Upload error:', error)
        alert('Ошибка при загрузке файла')
        this.progress = 0
      } finally {
        this.uploading = false
        if (this.previewUrl) {
          URL.revokeObjectURL(this.previewUrl)
          this.previewUrl = null
        }
      }
    },

    deleteFile(index) {
      const file = this.uploadedFiles[index]
      if (file.url && file.url.startsWith('blob:')) {
        URL.revokeObjectURL(file.url)
      }
      this.uploadedFiles.splice(index, 1)
      localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles))
    },

    clearAllFiles() {
      if (confirm('Вы уверены, что хотите удалить все файлы?')) {
        this.uploadedFiles.forEach(file => {
          if (file.url && file.url.startsWith('blob:')) {
            URL.revokeObjectURL(file.url)
          }
        })
        this.uploadedFiles = []
        localStorage.removeItem('uploadedFiles')
      }
    },

    copyLink(url) {
      navigator.clipboard.writeText(url)
        .then(() => {
          alert('Ссылка скопирована в буфер обмена')
        })
        .catch(err => {
          console.error('Failed to copy: ', err)
        })
    },

    editFile(index) {
      this.editingFile = index
      this.editingData = {
        customName: this.uploadedFiles[index].customName || '',
        description: this.uploadedFiles[index].description || ''
      }
    },

    saveFileEdit() {
      if (this.editingFile !== null) {
        this.uploadedFiles[this.editingFile] = {
          ...this.uploadedFiles[this.editingFile],
          customName: this.editingData.customName,
          description: this.editingData.description
        }

        localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles))
        this.editingFile = null
      }
    },

    limitDescription() {
      if (this.editingData.description.length > 500) {
        this.editingData.description = this.editingData.description.substring(0, 500)
      }
    }
  },

  beforeUnmount() {
    if (this.previewUrl) {
      URL.revokeObjectURL(this.previewUrl)
    }
    this.uploadedFiles.forEach(file => {
      if (file.url && file.url.startsWith('blob:')) {
        URL.revokeObjectURL(file.url)
      }
    })
  }
}
</script>

<style>
.progress-bar-transition {
  transition: width 0.3s ease-out;
}

tbody tr {
  transition: background-color 0.2s;
}

tbody tr:hover {
  background-color: #f8fafc;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s, transform 0.3s;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(10px);
}

.description-scroll {
  scrollbar-width: thin;
  scrollbar-color: #cbd5e0 #f1f5f9;
}

.description-scroll::-webkit-scrollbar {
  width: 4px;
}

.description-scroll::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 2px;
}

.description-scroll::-webkit-scrollbar-thumb {
  background-color: #cbd5e0;
  border-radius: 2px;
}
</style>