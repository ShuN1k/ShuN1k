<template>
    <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div class="bg-white rounded-xl shadow-lg w-full max-w-md">
        <div class="p-6">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900">
              {{ isLoginMode ? 'Вход в систему' : 'Регистрация' }}
            </h3>
            <button @click="closeModal" class="text-gray-400 hover:text-gray-500">
              <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
  
          <form @submit.prevent="submitForm">
            <div class="space-y-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Имя пользователя</label>
                <input
                  v-model="form.username"
                  type="text"
                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
              </div>
  
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Пароль</label>
                <input
                  v-model="form.password"
                  type="password"
                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
              </div>
  
              <div v-if="!isLoginMode">
                <label class="block text-sm font-medium text-gray-700 mb-1">Роль</label>
                <select
                  v-model="form.role"
                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="user">Пользователь</option>
                  <option value="editor">Редактор</option>
                  <option value="admin">Администратор</option>
                </select>
              </div>
  
              <div v-if="error" class="text-red-500 text-sm">
                {{ error }}
              </div>
  
              <div class="flex items-center justify-between">
                <button
                  type="button"
                  @click="toggleMode"
                  class="text-sm text-blue-600 hover:text-blue-800"
                >
                  {{ isLoginMode ? 'Нет аккаунта? Зарегистрируйтесь' : 'Уже есть аккаунт? Войдите' }}
                </button>
  
                <button
                  type="submit"
                  class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
                  :disabled="loading"
                >
                  <template v-if="!loading">
                    {{ isLoginMode ? 'Войти' : 'Зарегистрироваться' }}
                  </template>
                  <template v-else>
                    <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    {{ isLoginMode ? 'Вход...' : 'Регистрация...' }}
                  </template>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'AuthModal',
    props: {
      show: Boolean
    },
    data() {
      return {
        isLoginMode: true,
        loading: false,
        error: null,
        form: {
          username: '',
          password: '',
          role: 'user'
        }
      };
    },
    methods: {
      closeModal() {
        this.$emit('close');
        this.resetForm();
      },
      toggleMode() {
        this.isLoginMode = !this.isLoginMode;
        this.error = null;
      },
      resetForm() {
        this.form = {
          username: '',
          password: '',
          role: 'user'
        };
        this.error = null;
        this.isLoginMode = true;
      },
      async submitForm() {
        this.loading = true;
        this.error = null;
  
        try {
          const endpoint = this.isLoginMode ? '/login' : '/register';
          const response = await fetch(`http://localhost:3000${endpoint}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(this.form)
          });
  
          const data = await response.json();
  
          if (!response.ok) {
            throw new Error(data.message || 'Ошибка при выполнении запроса');
          }
  
          if (this.isLoginMode) {
            // Сохраняем токен и данные пользователя
            localStorage.setItem('token', data.token);
            localStorage.setItem('userRole', data.role);
            this.$emit('login-success', { token: data.token, role: data.role });
          } else {
            // После регистрации переключаемся в режим входа
            this.isLoginMode = true;
            this.$emit('registration-success');
          }
        } catch (err) {
          this.error = err.message;
        } finally {
          this.loading = false;
        }
      }
    }
  };
  </script>